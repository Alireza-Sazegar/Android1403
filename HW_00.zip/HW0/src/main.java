
public class main {

	public static void main(String[] args) {
		

	}
	public double circleArea(double R) {
		//Calculate Circle Area
		return R;
	}
	public double circlePerimeter(double R) {
		//Calculate Circle Circumference
		return R;
	}
	public int CastToInt(double x) {
		int y=0;
		//Cast x(double) to y(Integer)
		return y;
	}
	public int findMax(int[] x) {
		int max=x[0];
		//Find Maximum Element in Array(x)
		return max;
	}
}
